let count = 500
const countElement = document.getElementById('count')
const buyButton = document.getElementById('purchase')

function init() {
  countElement.innerHTML = count
}


buyButton.addEventListener('click', () => {
  const request = new PaymentRequest(buildSupportedPaymentMethodData(), buildShoppingCartDetails());
  request.canMakePayment().then(result => {

    if (result) {

      request.show().then(paymentResponse => {
        console.log(paymentResponse.details)
        // Here we would process the payment. For this demo, simulate immediate success:
        paymentResponse.complete('success')
          .then(() => location.href = "success.php")
      })
    }
  })
})

function buildSupportedPaymentMethodData() {
  // Example supported payment methods:
  return [{
    supportedMethods: 'basic-card',
    data: {
      supportedNetworks: ['visa', 'mastercard'],
      supportedTypes: ['debit', 'credit']
    }
  }];
}

function buildShoppingCartDetails() {
  return {
    id: 'count-order',
    displayItems: [
      {
        label: 'fine',
        amount: {currency: 'THB', value: '500.00'}
      }
    ],
    total: {
      label: 'Total',
      amount: {currency: 'THB', value: count }
    }
  };
}

init()
