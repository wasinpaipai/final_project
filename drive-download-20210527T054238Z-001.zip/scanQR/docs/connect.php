<?php
  $hostName="localhost";
  $user="root";
  $pass="";
  $dbName="code";
  $connect=mysqli_connect($hostName, $user, $pass, $dbName) or die("Not connect");
  echo "Connect";
 ?>
